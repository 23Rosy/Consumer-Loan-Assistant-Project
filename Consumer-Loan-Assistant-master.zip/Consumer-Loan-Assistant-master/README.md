Consumer Loan Assistant is java based loan assistant application using swing . Helps to accurately calculate number of EMIs or the monthly payments,the number of payments and also produces a loan summary for reference.

